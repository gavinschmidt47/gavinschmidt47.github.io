import java.util.Scanner;
public class DND_5e_character{
    public static void main(String[] args){
        characterStats player = new characterStats();
    }
}

class character{
    public String name;
    public int level;
    public String background;
    public String alignment;
    public String uClass;
    public String race;
    public String pName;
    public String[] languages;
    public String[] equipment;
    public int[] wealth = new int[5];

    public character(){
        Scanner input = new Scanner(System.in);
        System.out.print("Hello. What is your name?: ");
        pName = input.next();
        System.out.println("Welcome " + pName);

        System.out.print("Enter the character's name: ");
        name = input.next();

        System.out.print("Enter the class: " );
        uClass = input.next();

        System.out.print("Enter the race: ");
        race = input.next();

        System.out.print("Enter the level: ");
        level = input.nextInt();

        System.out.print("Enter alignment: ");
        alignment = input.next();

        System.out.print("Enter background: ");
        background = input.next();

        System.out.print("How many languages does " + name + " known?: ");
        int amount = input.nextInt();
        languages = new String[amount];
        System.out.print("Enter the languages one-by-one: ");
        for(int i = 0; i < amount; ++i){
            languages[i] = input.next();
        }

        System.out.print("How much equipment does " + name + " have?: ");
        amount = input.nextInt();
        equipment = new String[amount];
        System.out.print("Enter the equipment one-by-one: ");
        for(int i = 0; i < amount; ++i){
            equipment[i] = input.next();
        }

        System.out.print("How much copper does " + name + " have?: ");
        wealth[0] = input.nextInt();
        System.out.print("How much silver does " + name + " have?: ");
        wealth[1] = input.nextInt();
        System.out.print("How much electrum does " + name + " have?: ");
        wealth[2] = input.nextInt();
        System.out.print("How much gold does " + name + " have?: ");
        wealth[3] = input.nextInt();
        System.out.print("How much platinum does " + name + " have?: ");
        wealth[4] = input.nextInt();

        if(wealth[4] == 0 && wealth[3] < 100){
            System.out.println("It's okay. I'm not very rich either.");
        }
    }
}

class characterStats extends character{
    public int strength;
    public int dexterity;
    public int constitution;
    public int intelligence;
    public int wisdom;
    public int charisma;

    public int strengthMod;
    public int[] strengthSave = new int[2];
    public int[] athletics = new int[2];
    public int dexterityMod;
    public int[] dexteritySave = new int[2];
    public int[] acrobatics = new int[2];
    public int[] sleightOfHand = new int[2];
    public int[] stealth = new int[2];
    public int constitutionMod;
    public int[] constitutionSave = new int[2];
    public int intelligenceMod;
    public int[] intelligenceSave = new int[2];
    public int[] arcana = new int[2];
    public int[] history = new int[2];
    public int[] investigation = new int[2];
    public int[] nature = new int[2];
    public int[] religion = new int[2];
    public int wisdomMod;
    public int[] wisdomSave = new int[2];
    public int[] animalHandling = new int[2];
    public int[] insight = new int[2];
    public int[] medicine = new int[2];
    public int[] perception = new int[2];
    public int[] survival = new int[2];
    public int charismaMod;
    public int[] charismaSave = new int[2];
    public int[] deception = new int[2];
    public int[] intimidation = new int[2];
    public int[] performance = new int[2];
    public int[] persuasion = new int[2];

    public int passiveWisdom;
    public int speed;
    public int profBonus;
    public int maxHP;

    public characterStats(){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Strength, Dexterity, Constitution, Intelligence, Wisdom, and Charisma scores (after any racial bonuses): ");
        strength = input.nextInt();
        dexterity = input.nextInt();
        constitution = input.nextInt();
        intelligence = input.nextInt();
        wisdom = input.nextInt();
        charisma = input.nextInt();

        System.out.print("What is " + name + "'s speed?: ");
        speed = input.nextInt();

        System.out.println("What are " + name + "'s Saving Throws?:\n1. Strength\n2. Dexterity\n3. Constitution\n4. Intelligence\n5. Wisdom\n6. Charisma");
        int choice = input.nextInt();
        switch (choice) {
            case 1:
                strengthSave[1] = 1;
                dexteritySave[1] = 0;
                constitutionSave[1] = 0;
                intelligenceSave[1] = 0;
                wisdomSave[1] = 0;
                charismaSave[1] = 0;
                break;
            case 2:
                strengthSave[1] = 0;
                dexteritySave[1] = 1;
                constitutionSave[1] = 0;
                intelligenceSave[1] = 0;
                wisdomSave[1] = 0;
                charismaSave[1] = 0;
                break;
            case 3:
                strengthSave[1] = 0;
                dexteritySave[1] = 0;
                constitutionSave[1] = 1;
                intelligenceSave[1] = 0;
                wisdomSave[1] = 0;
                charismaSave[1] = 0;
                break;
            case 4:
                strengthSave[1] = 0;
                dexteritySave[1] = 0;
                constitutionSave[1] = 0;
                intelligenceSave[1] = 1;
                wisdomSave[1] = 0;
                charismaSave[1] = 0;
                break;
            case 5:
                strengthSave[1] = 0;
                dexteritySave[1] = 0;
                constitutionSave[1] = 0;
                intelligenceSave[1] = 0;
                wisdomSave[1] = 1;
                charismaSave[1] = 0;
                break;
            case 6:
                strengthSave[1] = 0;
                dexteritySave[1] = 0;
                constitutionSave[1] = 0;
                intelligenceSave[1] = 0;
                wisdomSave[1] = 0;
                charismaSave[1] = 1;
                break;

            default:
                break;
        }

        choice = input.nextInt();

        switch (choice) {
            case 1:
                strengthSave[1] = 1;
                break;
            case 2:
                dexteritySave[1] = 1;
                break;
            case 3:
                constitutionSave[1] = 1;
                break;
            case 4:
                intelligenceSave[1] = 1;
                break;
            case 5:
                wisdomSave[1] = 1;
                break;
            case 6:
                charismaSave[1] = 1;
                break;

            default:
                break;
        }

        System.out.print("What is the proficiency bonus: ");
        profBonus = input.nextInt();

        strengthMod = modFinder(strength);
        dexterityMod = modFinder(dexterity);
        constitutionMod = modFinder(constitution);
        intelligenceMod = modFinder(intelligence);
        wisdomMod = modFinder(wisdom);
        charismaMod = modFinder(charisma);

        athletics[1] = 0;
        acrobatics[1] = 0;
        sleightOfHand[1] = 0;
        stealth[1] = 0;
        arcana[1] = 0;
        history[1] = 0;
        investigation[1] = 0;
        nature[1] = 0;
        religion[1] = 0;
        animalHandling[1] = 0;
        insight[1] = 0;
        medicine[1] = 0;
        perception[1] = 0;
        survival[1] = 0;
        deception[1] = 0;
        intimidation[1] = 0;
        performance[1] = 0;
        persuasion[1] = 0;

        System.out.print("How many proficiencies does " + name + " have?: ");
        int amount = input.nextInt();
        System.out.println("What are " + name + "'s proficiencies?:\n1. Athletics\n2. Acrobatics\n3. Sleight-of-Hand\n4. Stealth\n5. Arcana\n6. History\n7. Investigation\n8. Nature\n9. Religion\n10. Animal Handling\n11. Insight\n12. Medicine\n13. Perception\n14. Survival\n15. Deception\n16. Intimidation\n17. Performance\n18. Persuasion");
        for(int i = 0; i < amount; ++i){
            choice = input.nextInt();
            switch (choice) {
                case 1:
                    athletics[1] = 1;
                    break;
                case 2:
                    acrobatics[1] = 1;
                    break;
                case 3:
                    sleightOfHand[1] = 1;
                    break;
                case 4:
                    stealth[1] = 1;
                    break;
                case 5:
                    arcana[1] = 1;
                    break;
                case 6:
                    history[1] = 1;
                    break;
                case 7:
                    investigation[1] = 1;
                    break;
                case 8:
                    nature[1] = 1;
                    break;
                case 9:
                    religion[1] = 1;
                    break;
                case 10:
                    animalHandling[1] = 1;
                    break;
                case 11:
                    insight[1] = 1;
                    break;
                case 12:
                    medicine[1] = 1;
                    break;
                case 13:
                    perception[1] = 1;
                    break;
                case 14:
                    survival[1] = 1;
                    break;
                case 15:
                    deception[1] = 1;
                    break;
                case 16:
                    intimidation[1] = 1;
                    break;
                case 17:
                    performance[1] = 1;
                    break;
                case 18:
                    persuasion[1] = 1;
                    break;
            
                default:
                    break;
            }
        }

        skillModFinder(strengthSave, strengthMod);
        skillModFinder(athletics, strengthMod);
        skillModFinder(dexteritySave, dexterityMod);
        skillModFinder(acrobatics, dexterityMod);
        skillModFinder(sleightOfHand, dexterityMod);
        skillModFinder(stealth, dexterityMod);
        skillModFinder(intelligenceSave, intelligenceMod);
        skillModFinder(arcana, intelligenceMod);
        skillModFinder(history, intelligenceMod);
        skillModFinder(investigation, intelligenceMod);
        skillModFinder(nature, intelligenceMod);
        skillModFinder(religion, intelligenceMod);
        skillModFinder(wisdomSave, wisdomMod);
        skillModFinder(animalHandling, wisdomMod);
        skillModFinder(insight, wisdomMod);
        skillModFinder(medicine, wisdomMod);
        skillModFinder(perception, wisdomMod);
        skillModFinder(survival, wisdomMod);
        skillModFinder(charismaSave, charismaMod);
        skillModFinder(deception, charismaMod);
        skillModFinder(intimidation, charismaMod);
        skillModFinder(performance, charismaMod);
        skillModFinder(persuasion, charismaMod);

        passiveWisdom = 10 + wisdomMod + perception[0];

        System.out.print("What is the max HP?: ");
        maxHP = input.nextInt();
    }

    public int modFinder(int stat){
        if(stat == 1){
            return -5;
        }
        else if(stat == 2 || stat == 3){
            return -4;
        }
        else if(stat == 4 || stat == 5){
            return -3;
        }
        else if(stat == 6 || stat == 7){
            return -2;
        }
        else if(stat == 8 || stat == 9){
            return -1;
        }
        else if(stat == 10 || stat == 11){
            return 0;
        }
        else if(stat == 12 || stat == 13){
            return 1;
        }
        else if(stat == 14 || stat == 15){
            return 2;
        }
        else if(stat == 16 || stat == 17){
            return 3;
        }
        else if(stat == 18 || stat == 19){
            return 4;
        }
        else if(stat == 20 || stat == 21){
            return 5;
        }
        else if(stat == 22 || stat == 23){
            return 6;
        }
        else if(stat == 24 || stat == 25){
            return 7;
        }
        else if(stat == 26 || stat == 27){
            return 8;
        }
        else if(stat == 28 || stat == 29){
            return 9;
        }
        else if(stat == 30){
            return 10;
        }
        return -111;
    }

    public void skillModFinder(int[] skill, int mod){
        if(skill[1] == 0){
            skill[0] = mod;
        }
        else if(skill[1] == 1){
            skill[0] = mod + profBonus;
        }
    }

    public String p(int skill[]){
        if(skill[1] == 1){
            return "np";
        }
        else{
            return "p";
        }

    }

    public void printPC(Armor ac){
        System.out.println(name);
        System.out.println("level: " + level + "\tclass: " + uClass + "\trace: " + race);
        System.out.println("Background: " + background + "\tAlignment: " + alignment + "\tplayer: " + pName);
        System.out.println(" ________ \t _________________ \t ________   ________   ________");
        System.out.println("|Strength|\t|Proficiency Bonus|\t|   " + ac.AC + "   | |   " + speed + "   | |   " + maxHP + "   |");
        System.out.println("|   " + strength + "   |\t|        " + profBonus + "        |\t|   AC   | | Speed  | |   HP   |");
        System.out.println("|   " + strengthMod + "   |\t -----------------\t --------   --------   --------");
        System.out.println(" --------\t _____________ \t ___________________ ");
        System.out.println("");

    }
}
class Armor{
    public int AC;


}